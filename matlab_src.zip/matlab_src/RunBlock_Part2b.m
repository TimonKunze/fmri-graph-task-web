function [E, runError] = RunBlock_Part2b(E, runIndex, startTrialIndex)
if nargin < 3 || isempty(startTrialIndex)
    startTrialIndex = 1;
end

% ExperimentScript records these anchors before each run. Keep RunBlock
% directly callable in tests/tools by supplying a deterministic fallback.
if ~isfield(E, 'part2') || ~isfield(E.part2, 'run') || ...
        numel(E.part2.run) < runIndex || ~isfield(E.part2.run(runIndex), 'triggerSecs')
    if ~isfield(E, 'begintime') || ~isfinite(E.begintime)
        E.begintime = GetSecs;
    end
    E.part2.run(runIndex).triggerSecs = E.begintime;
    E.part2.run(runIndex).taskStartSecs = E.begintime;
elseif ~isfield(E.part2.run(runIndex), 'taskStartSecs')
    E.part2.run(runIndex).taskStartSecs = E.part2.run(runIndex).triggerSecs;
end

runItems = E.assignment.part2RawNodeRuns{runIndex};
if ~isnumeric(startTrialIndex) || ~isscalar(startTrialIndex) || ...
        ~isfinite(startTrialIndex) || startTrialIndex ~= floor(startTrialIndex) || ...
        startTrialIndex < 1 || startTrialIndex > numel(runItems)
    error('RunBlock_Part2b:InvalidStartTrial', ...
        'Start trial must be one integer from 1 to %d for run %d.', ...
        numel(runItems), runIndex);
end

adjM = E.G.adjM;
shortestPathDistanceMatrix = createShortestPathDistanceMatrix(adjM);
canonicalToExp = invertPermutation(E.assignment.experimentNodeToGraphNode);

if startTrialIndex > 1
    [previousNodeIndex, previousItiSeconds, itiIndex] = primeResumeState( ...
        E, runItems, runIndex, startTrialIndex, adjM, canonicalToExp);
else
    previousNodeIndex = [];
    previousItiSeconds = [];
    itiIndex = 1;
end

runDeadlineSecs = GetSecs + E.times.runTimeoutSec;
runTimedOut = false;
SendEyeLinkMessage_Part2b(E, 'RUN_START %d', runIndex);
runSkipped = false;
pendingItiIndex = [];
pendingImageIndex = [];
nextStimulusDeadlineSecs = 0;
preparedFixation = [];

runError = [];
try
for trialIndex = startTrialIndex:numel(runItems)
    E = FlushResultsMat_Part2b(E, 'collect'); % Nonblocking; no file I/O.
    runTimedOut = runTimedOut || GetSecs >= runDeadlineSecs;
    if runSkipped || runTimedOut
        break;
    end
    item = runItems{trialIndex};

    if isnumeric(item) && isscalar(item)
        decoded = decodeFmriNode(item, size(adjM, 1), canonicalToExp, E);
        SendEyeLinkMessage_Part2b(E, 'TRIALID R%d_T%d', runIndex, trialIndex);
        SendEyeLinkMessage_Part2b(E, 'TRIAL_VAR RAW_NODE %d GRAPH_NODE %d', decoded.rawNode, decoded.graphNodeIndex);
        [imageOnsetSecs, imageOnsetClock, runSkipped, runTimedOut, imageFlip] = ...
            drawSingleImageTrial(E, decoded.imageTex, nextStimulusDeadlineSecs, runDeadlineSecs);
        if ~isfinite(imageOnsetSecs)
            SendEyeLinkMessage_Part2b(E, 'TRIAL_RESULT 1');
            break;
        end
        E = finishIti(E, pendingItiIndex, imageOnsetSecs);
        pendingItiIndex = [];
        nextStimulusDeadlineSecs = 0;
        SendEyeLinkMessage_Part2b(E, 'IMAGE_ONSET %d %d %d %d', runIndex, trialIndex, decoded.rawNode, decoded.graphNodeIndex);
        imageDeadlineSecs = imageOnsetSecs + E.times.imagePresentationMs / 1000;
        pendingImageIndex = numel(E.part2.trials) + 1;
            E.part2.trials{pendingImageIndex} = struct( ...
                'trial_name', 'part2_fmri_picture_viewing', ...
            'part', 2, ...
            'run_index', runIndex, ...
            'trial_index', trialIndex, ...
            'raw_node_index', decoded.rawNode, ...
            'graph_node_index', decoded.graphNodeIndex, ...
            'layout_type', decoded.layoutType, ...
            'stim_set', decoded.stimSet, ...
            'image_src', decoded.imageSrc, ...
            'object_id', getObjectId(E, decoded), ...
            'flip', imageFlip, ...
            'duration_ms', E.times.imagePresentationMs, ...
            'actual_duration_ms', NaN, ...
            'presentation_deadline_secs', imageDeadlineSecs, ...
                'timestamp_sec', imageOnsetSecs, ...
                'timestamp_rel_sec', imageOnsetSecs - E.begintime, ...
                'onset_from_trigger', imageOnsetSecs - E.part2.run(runIndex).triggerSecs, ...
                'onset_from_task_start', imageOnsetSecs - E.part2.run(runIndex).taskStartSecs, ...
                'timestamp_clock', imageOnsetClock, ...
                'run_skipped', runSkipped, ...
                'timed_out', runTimedOut);
        % Draw the image-offset fixation while the image is still visible,
        % then schedule its flip for the planned end of the image period.
        [fixSecs, fixClock, fixFlip, runSkipped, runTimedOut] = ...
            drawFixationTrial(E, imageDeadlineSecs, runDeadlineSecs);
        if isfinite(fixSecs)
            preparedFixation = struct('onset', fixSecs, 'clock', fixClock, 'flip', fixFlip);
            E = finishStimulus(E, pendingImageIndex, fixFlip.onset, fixFlip);
        end
        E.part2.trials{pendingImageIndex}.run_skipped = runSkipped;
        E.part2.trials{pendingImageIndex}.timed_out = runTimedOut;
        SendEyeLinkMessage_Part2b(E, 'TRIAL_RESULT %d', double(runSkipped || runTimedOut));

        previousNodeIndex = decoded.experimentNodeIndex;

        if runSkipped
            SendEyeLinkMessage_Part2b(E, 'RUN_SKIP %d', runIndex);
            break;
        end

        runTimedOut = runTimedOut || GetSecs >= runDeadlineSecs;
        if runTimedOut
            break;
        end
        if trialIndex < numel(runItems)
            itiSeconds = getItiSeconds(E, E.assignment.part2ItiTimesFmri, runIndex, itiIndex, E.sbj.n);
            [E, pendingItiIndex, nextStimulusDeadlineSecs, itiError] = ...
                beginIti(E, runIndex, trialIndex, itiSeconds, false, pendingImageIndex, preparedFixation);
            preparedFixation = [];
            pendingImageIndex = [];
            if ~isempty(itiError), rethrow(itiError); end
            previousItiSeconds = itiSeconds;
            itiIndex = itiIndex + 1;
        end
        continue;
    end

    if isnumeric(item) && numel(item) == 2
        leftNode = decodeFmriNode(item(1), size(adjM, 1), canonicalToExp, E);
        rightNode = decodeFmriNode(item(2), size(adjM, 1), canonicalToExp, E);

        if isempty(previousNodeIndex)
            leftPathLength = NaN;
            rightPathLength = NaN;
            correctChoice = NaN;
        else
            leftPathLength = shortestPathDistanceMatrix(previousNodeIndex + 1, leftNode.experimentNodeIndex + 1);
            rightPathLength = shortestPathDistanceMatrix(previousNodeIndex + 1, rightNode.experimentNodeIndex + 1);
            if leftPathLength == rightPathLength
                correctChoice = NaN;
            elseif leftPathLength < rightPathLength
                correctChoice = 0;
            else
                correctChoice = 1;
            end
        end

        SendEyeLinkMessage_Part2b(E, 'TRIALID R%d_T%d', runIndex, trialIndex);
        SendEyeLinkMessage_Part2b(E, 'TRIAL_VAR LEFT_OBJECT_ID %d', getObjectId(E, leftNode));
        SendEyeLinkMessage_Part2b(E, 'TRIAL_VAR RIGHT_OBJECT_ID %d', getObjectId(E, rightNode));
        SendEyeLinkMessage_Part2b(E, 'TRIAL_VAR LEFT_GRAPH_NODE %d RIGHT_GRAPH_NODE %d', ...
            leftNode.graphNodeIndex, rightNode.graphNodeIndex);

        trialInfo = struct( ...
            'runIndex', runIndex, ...
            'trialIndex', trialIndex, ...
            'leftRawNode', item(1), ...
            'rightRawNode', item(2), ...
            'referenceNodeIndex', previousNodeIndex, ...
            'leftPathLength', leftPathLength, ...
            'rightPathLength', rightPathLength, ...
            'correctChoice', correctChoice);

        [response, responseSide, rtSecs, choiceOnsetSecs, choiceOnsetClock, skipRunChoice, runTimedOut, responseTimestampSecs, choiceFlip, responseError] = GetKeyResp_Part2b(E, leftNode.imageTex, rightNode.imageTex, trialInfo, runDeadlineSecs, nextStimulusDeadlineSecs);
        if ~isfinite(choiceOnsetSecs)
            if ~isempty(responseError), rethrow(responseError); end
            runSkipped = skipRunChoice;
            SendEyeLinkMessage_Part2b(E, 'TRIAL_RESULT 1');
            break;
        end
        E = finishIti(E, pendingItiIndex, choiceOnsetSecs);
        pendingItiIndex = [];
        nextStimulusDeadlineSecs = 0;
        E.part2.trials{end + 1} = struct( ...
            'trial_name', 'part2_dual_stimulus_choice', ...
            'part', 2, ...
            'run_index', runIndex, ...
            'trial_index', trialIndex, ...
            'left_raw_node_index', item(1), ...
            'right_raw_node_index', item(2), ...
            'left_graph_node_index', leftNode.graphNodeIndex, ...
            'right_graph_node_index', rightNode.graphNodeIndex, ...
            'left_node_index', leftNode.experimentNodeIndex, ...
            'right_node_index', rightNode.experimentNodeIndex, ...
            'reference_experiment_node_index', previousNodeIndex, ...
            'reference_graph_node_index', referenceGraphNodeIndex(E, previousNodeIndex), ...
            'iti_seconds_previous', previousItiSeconds, ...
            'path_length_left', leftPathLength, ...
            'path_length_right', rightPathLength, ...
            'path_lengths', [leftPathLength, rightPathLength], ...
            'correct_choice', correctChoice, ...
            'stim_set', leftNode.stimSet, ...
            'layout_type', leftNode.layoutType, ...
            'left_image_src', leftNode.imageSrc, ...
            'right_image_src', rightNode.imageSrc, ...
            'left_object_id', getObjectId(E, leftNode), ...
            'right_object_id', getObjectId(E, rightNode), ...
            'right_layout_type', rightNode.layoutType, ...
            'right_stim_set', rightNode.stimSet, ...
            'flip', choiceFlip, ...
            'interrupted', ~isempty(responseError), ...
            'response', response, ...
            'response_side', responseSide, ...
            'rt_seconds', rtSecs, ...
            'response_timestamp_sec', responseTimestampSecs, ...
            'timed_out', any(strcmp(responseSide, {'timeout', 'run_timeout'})), ...
            'timestamp_sec', choiceOnsetSecs, ...
            'timestamp_rel_sec', choiceOnsetSecs - E.begintime, ...
            'onset_from_trigger', choiceOnsetSecs - E.part2.run(runIndex).triggerSecs, ...
            'onset_from_task_start', choiceOnsetSecs - E.part2.run(runIndex).taskStartSecs, ...
            'timestamp_clock', choiceOnsetClock, ...
            'run_skipped', skipRunChoice);
        pendingImageIndex = numel(E.part2.trials); % Active picture OR choice.
        if ~isempty(responseError), rethrow(responseError); end
        SendEyeLinkMessage_Part2b(E, 'TRIAL_RESULT %d', double(skipRunChoice || runTimedOut));
        E.part2.resultsMatNeedsFlush = true;

        previousNodeIndex = [];

        if skipRunChoice
            runSkipped = true;
            SendEyeLinkMessage_Part2b(E, 'RUN_SKIP %d', runIndex);
            break;
        end

        runTimedOut = runTimedOut || GetSecs >= runDeadlineSecs;
        if runTimedOut
            break;
        end
        if trialIndex < numel(runItems)
            itiSeconds = getItiSeconds(E, E.assignment.part2ItiTimesFmri, runIndex, itiIndex, E.sbj.n);
            [E, pendingItiIndex, nextStimulusDeadlineSecs, itiError] = ...
                beginIti(E, runIndex, trialIndex, itiSeconds, true, pendingImageIndex);
            pendingImageIndex = [];
            if ~isempty(itiError), rethrow(itiError); end
            previousItiSeconds = itiSeconds;
            itiIndex = itiIndex + 1;
        end
    end
end

if runSkipped && ~isempty(pendingItiIndex)
    E.part2.trials{pendingItiIndex}.run_skipped = true;
    SendEyeLinkMessage_Part2b(E, 'RUN_SKIP %d', runIndex);
end
if runTimedOut
    % Clear the current stimulus before saving and returning to the run break.
    Screen('FillRect', E.screen.theWindow, E.screen.bckgrnd);
    offsetFlip = struct('scheduled', false, 'requestedOnsetSecs', 0, ...
        'when', 0, 'submittedSecs', GetSecs);
    [offsetFlip.vbl, offsetFlip.onset, offsetFlip.finished, offsetFlip.missed] = ...
        Screen('Flip', E.screen.theWindow);
    E = finishStimulus(E, pendingImageIndex, offsetFlip.onset, offsetFlip);
    timeoutSecs = GetSecs;
    SendEyeLinkMessage_Part2b(E, 'RUN_TIMEOUT %d', runIndex);
    E.part2.trials{end + 1} = struct( ...
        'trial_name', 'part2_run_timeout', ...
        'part', 2, 'run_index', runIndex, ...
        'timed_out', true, ...
        'timestamp_sec', timeoutSecs, ...
        'timestamp_rel_sec', timeoutSecs - E.begintime, ...
        'onset_from_trigger', timeoutSecs - E.part2.run(runIndex).triggerSecs, ...
        'onset_from_task_start', timeoutSecs - E.part2.run(runIndex).taskStartSecs, ...
        'timestamp_clock', datestr(now, 'yyyy-mm-dd HH:MM:SS.FFF'));
end
if ~runSkipped && ~runTimedOut
    % This begins after the final response/choice handler returns, so the
    % full baseline follows the response-dependent final trial.
    postRunFixationSec = 8;
    if isfield(E, 'times') && isfield(E.times, 'postRunFixationSec') && ...
            isfinite(E.times.postRunFixationSec) && E.times.postRunFixationSec >= 0
        postRunFixationSec = E.times.postRunFixationSec;
    end
    if isempty(preparedFixation)
        [fixationOnsetSecs, fixationOnsetClock, fixationFlip] = drawFixationTrial(E);
    else
        fixationOnsetSecs = preparedFixation.onset;
        fixationOnsetClock = preparedFixation.clock;
        fixationFlip = preparedFixation.flip;
    end
    E = finishStimulus(E, pendingImageIndex, fixationFlip.onset, fixationFlip);
    SendEyeLinkMessage_Part2b(E, 'POST_RUN_FIXATION_ONSET %d %d', ...
        runIndex, round(postRunFixationSec * 1000));
    E.part2.trials{end + 1} = struct( ...
        'trial_name', 'part2_fmri_post_run_fixation', ...
        'part', 2, 'run_index', runIndex, ...
        'trial_index', numel(runItems) + 1, ...
        'duration_sec', postRunFixationSec, ...
        'flip', fixationFlip, ...
        'timestamp_sec', fixationOnsetSecs, ...
        'timestamp_rel_sec', fixationOnsetSecs - E.begintime, ...
        'onset_from_trigger', fixationOnsetSecs - E.part2.run(runIndex).triggerSecs, ...
        'onset_from_task_start', fixationOnsetSecs - E.part2.run(runIndex).taskStartSecs, ...
        'timestamp_clock', fixationOnsetClock, ...
        'run_skipped', false, 'timed_out', false);
    pendingImageIndex = [];
    pendingItiIndex = numel(E.part2.trials);
    WaitSecs(postRunFixationSec);
    pendingItiIndex = [];
end
E.part2.run(runIndex).status = 'completed';
if runSkipped, E.part2.run(runIndex).status = 'skipped'; end
if runTimedOut, E.part2.run(runIndex).status = 'timed_out'; end
SendEyeLinkMessage_Part2b(E, 'RUN_END %d', runIndex);
% Final fixation above is part of the run; capture stops only after its wait.
E = FlushResultsMat_Part2b(E, 'stop'); % End capture before checkpoint I/O.
E = FlushResultsMat_Part2b(E);
E.part2.resultsMatNeedsFlush = false;
catch err
    runError = err;
    E.part2.run(runIndex).status = 'interrupted';
    E.part2.run(runIndex).errorIdentifier = err.identifier;
    E.part2.run(runIndex).errorMessage = err.message;
    if ~isempty(pendingImageIndex)
        E.part2.trials{pendingImageIndex}.interrupted = true;
    end
    if ~isempty(pendingItiIndex)
        E.part2.trials{pendingItiIndex}.interrupted = true;
    end
    % No disk I/O while an experimental stimulus is being presented.
    % Production returns partial E to the outer cleanup/export path.
    if nargout < 2, rethrow(err); end
end

end

function graphNodeIndex = referenceGraphNodeIndex(E, experimentNodeIndex)
if isempty(experimentNodeIndex) || ~isfinite(experimentNodeIndex)
    graphNodeIndex = NaN;
    return;
end
graphNodeIndex = E.assignment.experimentNodeToGraphNode(experimentNodeIndex + 1);
end

function decoded = decodeFmriNode(rawNode, nbNodes, canonicalToExp, E)
graphNodeIndex = mod(rawNode, nbNodes);
if rawNode < nbNodes
    stimSet = 'set1';
    layoutType = 'rotational';
else
    stimSet = 'set2';
    layoutType = 'unconstrained';
end

experimentNodeIndex = canonicalToExp(graphNodeIndex + 1);
if isnan(experimentNodeIndex)
    error('RunBlock_Part2b:UnmappedNode', ...
        'Could not map graph node %d to experiment node for raw fMRI node %d.', ...
        graphNodeIndex, rawNode);
end

imageSrc = indexedStimulus(E.Stim.nodePaths.(stimSet), experimentNodeIndex + 1);
imageTex = indexedStimulus(E.Stim.nodeTextures.(stimSet), experimentNodeIndex + 1);

decoded = struct( ...
    'rawNode', rawNode, ...
    'stimSet', stimSet, ...
    'layoutType', layoutType, ...
    'graphNodeIndex', graphNodeIndex, ...
    'experimentNodeIndex', experimentNodeIndex, ...
    'imageSrc', imageSrc, ...
    'imageTex', imageTex);
end

function value = indexedStimulus(container, index)
% Production preload uses cell arrays; timing tests may use numeric handles.
if iscell(container)
    value = container{index};
else
    value = container(index);
end
end

function canonicalToExp = invertPermutation(expToCanonical)
nb = numel(expToCanonical);
canonicalToExp = nan(1, nb);
for experimentIndex = 1:nb
    canonicalIndex = double(expToCanonical(experimentIndex));
    canonicalToExp(canonicalIndex + 1) = experimentIndex - 1;
end
end

function [previousNodeIndex, previousItiSeconds, itiIndex] = primeResumeState(E, runItems, runIndex, startTrialIndex, adjM, canonicalToExp)
previousNodeIndex = [];
previousItiSeconds = [];
itiIndex = 1;

for trialIndex = 1:(startTrialIndex - 1)
    item = runItems{trialIndex};

    if isnumeric(item) && isscalar(item)
        decoded = decodeFmriNode(item, size(adjM, 1), canonicalToExp, E);
        previousNodeIndex = decoded.experimentNodeIndex;
    elseif isnumeric(item) && numel(item) == 2
        previousNodeIndex = [];
    end

    if trialIndex < numel(runItems)
        itiSeconds = getItiSeconds(E, E.assignment.part2ItiTimesFmri, runIndex, itiIndex, E.sbj.n);
        previousItiSeconds = itiSeconds;
        itiIndex = itiIndex + 1;
    end
end
end

function [E, recordIndex, deadlineSecs, itiError] = beginIti(E, runIndex, trialIndex, itiSeconds, saveCheckpoint, previousImageIndex, preparedFixation)
if nargin < 6
    previousImageIndex = [];
end
if nargin < 7 || isempty(preparedFixation)
    [onsetSecs, onsetClock, fixationFlip] = drawFixationTrial(E);
else
    onsetSecs = preparedFixation.onset;
    onsetClock = preparedFixation.clock;
    fixationFlip = preparedFixation.flip;
end
deadlineSecs = onsetSecs + itiSeconds;
SendEyeLinkMessage_Part2b(E, 'ITI_ONSET %d %d %d', runIndex, trialIndex, round(itiSeconds * 1000));
E = finishStimulus(E, previousImageIndex, fixationFlip.onset, fixationFlip);
recordIndex = numel(E.part2.trials) + 1;
% This record denotes ITI onset, not completion. Actual duration is filled
% after the next stimulus flips; a checkpoint taken now keeps it as NaN.
E.part2.trials{recordIndex} = struct( ...
    'trial_name', 'part2_fmri_iti', 'part', 2, ...
    'run_index', runIndex, 'trial_index', trialIndex, ...
    'iti_seconds', itiSeconds, 'iti_deadline_sec', deadlineSecs, ...
    'flip', fixationFlip, ...
    'iti_actual_seconds', NaN, 'iti_lateness_seconds', NaN, ...
    'checkpoint_save_seconds', NaN, ...
    'timestamp_sec', onsetSecs, 'timestamp_rel_sec', onsetSecs - E.begintime, ...
    'onset_from_trigger', onsetSecs - E.part2.run(runIndex).triggerSecs, ...
    'onset_from_task_start', onsetSecs - E.part2.run(runIndex).taskStartSecs, ...
    'timestamp_clock', onsetClock, 'run_skipped', false);
itiError = [];
if saveCheckpoint
    saveStartedSecs = GetSecs;
    try
        E = FlushResultsMat_Part2b(E, 'collect');
        % Separate assignment retains these pulses if the disk write throws.
        E = FlushResultsMat_Part2b(E);
        E.part2.resultsMatNeedsFlush = false;
        E.part2.trials{recordIndex}.checkpoint_save_seconds = GetSecs - saveStartedSecs;
    catch err
        itiError = err;
    end
end
end

function E = finishIti(E, recordIndex, nextOnsetSecs)
if isempty(recordIndex)
    return;
end
iti = E.part2.trials{recordIndex};
iti.iti_actual_seconds = nextOnsetSecs - iti.timestamp_sec;
iti.iti_lateness_seconds = max(0, nextOnsetSecs - iti.iti_deadline_sec);
E.part2.trials{recordIndex} = iti;
end

function [vbl, clockStamp, skipped, timedOut, flip] = drawSingleImageTrial(E, imageTex, deadlineSecs, runDeadlineSecs)
Screen('FillRect', E.screen.theWindow, E.screen.bckgrnd);
imageWidth = 320;
imageHeight = 320;
rect = CenterRectOnPointd([0 0 imageWidth imageHeight], E.screen.cx, E.screen.cy);
Screen('DrawTexture', E.screen.theWindow, imageTex, [], rect);
[vbl, skipped, timedOut, flip] = FlipPreparedStimulus_Part2b(E, deadlineSecs, runDeadlineSecs);
clockStamp = '';
if isfinite(vbl)
    clockStamp = datestr(now, 'yyyy-mm-dd HH:MM:SS.FFF');
end
end

function [vbl, clockStamp, flip, skipped, timedOut] = drawFixationTrial(E, deadlineSecs, runDeadlineSecs)
Screen('FillRect', E.screen.theWindow, E.screen.bckgrnd);
Screen('TextSize', E.screen.theWindow, E.screen.textsize * 2);
DrawFormattedText(E.screen.theWindow, '+', 'center', E.screen.cy, E.screen.textcolor);
if nargin > 1
    [vbl, skipped, timedOut, flip] = FlipPreparedStimulus_Part2b(E, deadlineSecs, runDeadlineSecs);
    clockStamp = '';
    if isfinite(vbl), clockStamp = datestr(now, 'yyyy-mm-dd HH:MM:SS.FFF'); end
    return;
end
skipped = false;
timedOut = false;
flip.scheduled = false;
flip.requestedOnsetSecs = 0;
flip.when = 0;
flip.submittedSecs = GetSecs;
[flip.vbl, flip.onset, flip.finished, flip.missed] = Screen('Flip', E.screen.theWindow);
vbl = flip.vbl;
if ~isfinite(vbl)
    vbl = GetSecs;
end
clockStamp = datestr(now, 'yyyy-mm-dd HH:MM:SS.FFF');
end

function [skipped, timedOut] = waitSecsWithRunSkip(E, durationSecs, runDeadlineSecs)
skipped = false;
timedOut = false;
startTime = GetSecs;
while true
    nowSecs = GetSecs;
    if nowSecs >= runDeadlineSecs
        timedOut = true;
        break;
    end
    elapsed = nowSecs - startTime;
    if elapsed >= durationSecs
        break;
    end
    [keyIsDown, ~, keyCode] = KbCheck;
    if keyIsDown && keyCode(E.keys.enter) && any(keyCode(E.keys.shift))
        skipped = true;
        break;
    end
    WaitSecs(min([0.01, durationSecs - elapsed, runDeadlineSecs - nowSecs]));
end
end

function itiSeconds = getItiSeconds(E, part2ItiRuns, runIndex, itiIndex, subjectCode)
runIti = getRunItiValues(part2ItiRuns, runIndex, subjectCode);
if itiIndex < 1 || itiIndex > numel(runIti)
    error('RunBlock_Part2b:MissingITI', 'Missing ITI value for run %d, iti index %d, subject %s.', runIndex, itiIndex, num2str(subjectCode));
end
itiSeconds = double(runIti(itiIndex));
if ~isfinite(itiSeconds)
    error('RunBlock_Part2b:InvalidITI', 'Missing ITI value for run %d, iti index %d, subject %s.', runIndex, itiIndex, num2str(subjectCode));
end
if isfield(E, 'debugmode') && E.debugmode
    itiSeconds = itiSeconds / 2;
end
end

function runIti = getRunItiValues(part2ItiRuns, runIndex, subjectCode)
if iscell(part2ItiRuns)
    if numel(part2ItiRuns) < runIndex || isempty(part2ItiRuns{runIndex})
        error('RunBlock_Part2b:MissingITI', 'Missing ITI values for run %d, subject %s.', runIndex, num2str(subjectCode));
    end
    runIti = part2ItiRuns{runIndex};
    return;
end

if isnumeric(part2ItiRuns)
    if ndims(part2ItiRuns) == 2
        if size(part2ItiRuns, 1) < runIndex
            error('RunBlock_Part2b:MissingITI', 'Missing ITI values for run %d, subject %s.', runIndex, num2str(subjectCode));
        end
        runIti = part2ItiRuns(runIndex, :);
        return;
    end
    if ndims(part2ItiRuns) == 3
        if size(part2ItiRuns, 1) < runIndex
            error('RunBlock_Part2b:MissingITI', 'Missing ITI values for run %d, subject %s.', runIndex, num2str(subjectCode));
        end
        runIti = squeeze(part2ItiRuns(runIndex, :, :));
        runIti = runIti(:).';
        return;
    end
end

error('RunBlock_Part2b:InvalidITIContainer', 'Unsupported ITI container for run %d, subject %s.', runIndex, num2str(subjectCode));
end

function objectId = getObjectId(E, decoded)
objectId = NaN;
if ~isfield(E.assignment, 'objectToNodes'), return; end
objectOffset = strcmp(decoded.stimSet, 'set2') * 8;
objectId = E.assignment.objectToNodes(decoded.experimentNodeIndex + 1 + objectOffset);
end

function matrix = createShortestPathDistanceMatrix(adjM)
nbNodes = size(adjM, 1);
matrix = inf(nbNodes);
matrix(1:nbNodes+1:end) = 0;
[rows, cols] = find(adjM > 0);
for i = 1:numel(rows)
    matrix(rows(i), cols(i)) = 1;
end
for k = 1:nbNodes
    for i = 1:nbNodes
        for j = 1:nbNodes
            alt = matrix(i, k) + matrix(k, j);
            if alt < matrix(i, j)
                matrix(i, j) = alt;
            end
        end
    end
end
end

function E = finishStimulus(E, index, offsetSecs, offsetFlip)
if isempty(index), return; end
t = E.part2.trials{index};
% A later timeout clear must not replace an already observed image offset.
if isfield(t, 'offset_flip'), return; end
t.offset_sec = offsetSecs;
t.offset_flip = offsetFlip;
if isfield(t, 'flip') && isfinite(t.flip.onset) && isfinite(offsetSecs)
    t.actual_duration_ms = 1000 * (offsetSecs - t.flip.onset);
end
E.part2.trials{index} = t;
end
